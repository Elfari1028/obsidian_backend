from django.shortcuts import render
from django.http import JsonResponse
from .models import MyUser
from django.db.utils import IntegrityError
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
import simplejson
import json

# Create your views here.


def register1(request):
    # register_data = simplejson.loads(request.body, strict=False)
    # userName = register_data['username']
    # password = register_data['password']
    # email = register_data['email']
    userName = request.POST['username']
    password = request.POST['password']
    email = request.POST['email']
    try:
        user = MyUser.objects.create_user(userName, email, password)
        user.save()
        return JsonResponse({"message": "register success", "status": 0})
    except IntegrityError:
        return JsonResponse({"message": "the username has been used", "status": 1})


def login1(request):
    userName = request.POST['username']
    pwd = request.POST['password']

    if request.user.is_authenticated:
        # 方法1 如果登录了则要求注销后再登录
        return JsonResponse({"message": "you have logged in, please logout to change account", "status": 2})
        # 方法2 自动注销上一次登录，然后进行本次登录
        # logout(request)
    user = authenticate(username=userName, password=pwd)
    if user is not None:
        login(request, user)
        request.session['userType'] = 'user'
        return JsonResponse({"message": "login success", "status": 0})
    return JsonResponse({"message": "username or password error", "status": 1})


def logout1(request):
    logout(request)
    return JsonResponse({"message": "logout success", "status": 0})


def my_status(request):
    if request.user.is_authenticated:
        return JsonResponse({"message": "you have logged in", "username": request.user.username, "status": 0})
    else:
        return JsonResponse({"message": "please login or register", "status": 1})